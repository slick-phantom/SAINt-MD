export default {
    name: "help",
    description: "Show all available commands and how to use them",
    category: "utility",
    async execute(message, client, args) {
        try {
            // Get specific category if provided
            const requestedCategory = args[0]?.toLowerCase();
            
            // Get all commands
            const commands = client.commandHandler?.commands || new Map();
            const commandList = Array.from(commands.values());
            
            // Sort commands alphabetically
            commandList.sort((a, b) => a.name.localeCompare(b.name));
            
            // Group commands by category
            const categorizedCommands = {};
            commandList.forEach(cmd => {
                const category = cmd.category || 'general';
                if (!categorizedCommands[category]) {
                    categorizedCommands[category] = [];
                }
                categorizedCommands[category].push(cmd);
            });
            
            let helpMessage = `🤖 *SAVY DNI BOT - HELP MENU* 🤖\n\n`;
            
            // Show specific category or all categories
            if (requestedCategory && categorizedCommands[requestedCategory]) {
                // Show specific category
                helpMessage += `📂 *${requestedCategory.toUpperCase()} COMMANDS*\n\n`;
                
                categorizedCommands[requestedCategory].forEach(cmd => {
                    helpMessage += `• !${cmd.name} - ${cmd.description || 'No description'}\n`;
                });
                
                helpMessage += `\n💡 Usage: !command [parameters]\nExample: !translate es Hello\n\n`;
                
            } else if (requestedCategory) {
                // Category not found
                helpMessage += `❌ Category "${requestedCategory}" not found.\n\n`;
                helpMessage += `Available categories:\n`;
                
                Object.keys(categorizedCommands).forEach(category => {
                    helpMessage += `• ${category}\n`;
                });
                
                helpMessage += `\nUse !help [category] to see commands in a specific category.\n`;
                
            } else {
                // Show all categories
                helpMessage += `Available categories:\n\n`;
                
                for (const [category, cmds] of Object.entries(categorizedCommands)) {
                    helpMessage += `📂 *${category.toUpperCase()}* (${cmds.length} commands)\n`;
                }
                
                helpMessage += `\n💡 Use !help [category] to see commands in a specific category.\n`;
                helpMessage += `Example: !help utility\n\n`;
            }
            
            // Add WhatsApp channel invitation
            helpMessage += `📢 *JOIN OUR WHATSAPP CHANNEL*\n`;
            helpMessage += `Get updates, news, and tips:\n`;
            helpMessage += `https://whatsapp.com/channel/0029VbBNepmLY6d2gd7NfA07\n\n`;
            
            // Add support information
            helpMessage += `❓ Need help? Contact support for assistance.`;
            
            // Send the help message
            await client.sendMessage(
                message.key.remoteJid,
                { text: helpMessage },
                { quoted: message }
            );
            
        } catch (error) {
            console.error('Error executing help command:', error);
            
            // Simple fallback message
            await client.sendMessage(
                message.key.remoteJid,
                { 
                    text: `🤖 *SAVY DNI BOT HELP*\n\nUse !help to see all commands or !help [category] to see commands in a specific category.\n\n📢 Join our channel for updates:\nhttps://whatsapp.com/channel/0029VbBNepmLY6d2gd7NfA07` 
                },
                { quoted: message }
            );
        }
    }
};